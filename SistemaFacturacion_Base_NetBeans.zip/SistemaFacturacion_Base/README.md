# Sistema de Facturación - Base del proyecto

Proyecto Java Maven para abrir en NetBeans. Incluye paquetes y clases base, **sin JFrame**.

## Paquetes
- `conexion`: conexión JDBC con MySQL.
- `modelo`: entidades Cliente, Producto, Usuario, Factura y DetalleFactura.
- `dao`: clases de acceso a datos.
- `servicio`: lógica de facturación (maestro-detalle).

## Abrir en NetBeans
1. Descomprima el ZIP.
2. En NetBeans seleccione **File > Open Project** y elija la carpeta `SistemaFacturacion`.
3. Configure MySQL y ejecute `sql/ventas.sql`.
4. Edite `conexion/ConexionBD.java` con su usuario y contraseña de MySQL.
5. Los formularios JFrame se pueden agregar después, dentro de un paquete `vista`.

## GitHub en equipo
Una persona crea un repositorio vacío en GitHub y agrega a los demás como colaboradores.
Luego, cada integrante clona el repositorio. Antes de empezar a trabajar: `Pull`; al terminar: `Commit` y `Push`.
Eviten editar el mismo archivo al mismo tiempo. No suban contraseñas reales ni carpetas `target/` o `nbproject/private/`.

## Nota
Esta es una estructura inicial: las entidades y la conexión están preparadas; los DAO contienen operaciones base para completar/probar junto con la base MySQL y los JFrame.
