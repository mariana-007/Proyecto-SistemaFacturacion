package cr.utn.facturacion.modelo;

import java.math.BigDecimal;

public class Producto {
    private String codigo, descripcion;
    private BigDecimal precio;
    private int existencia;
    public Producto() {}
    public Producto(String codigo, String descripcion, BigDecimal precio, int existencia) {
        this.codigo=codigo; this.descripcion=descripcion; this.precio=precio; this.existencia=existencia;
    }
    public String getCodigo(){return codigo;} public void setCodigo(String v){codigo=v;}
    public String getDescripcion(){return descripcion;} public void setDescripcion(String v){descripcion=v;}
    public BigDecimal getPrecio(){return precio;} public void setPrecio(BigDecimal v){precio=v;}
    public int getExistencia(){return existencia;} public void setExistencia(int v){existencia=v;}
}
