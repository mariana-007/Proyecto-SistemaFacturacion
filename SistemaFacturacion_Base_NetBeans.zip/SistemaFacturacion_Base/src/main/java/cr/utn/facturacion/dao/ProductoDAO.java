package cr.utn.facturacion.dao;

import cr.utn.facturacion.conexion.ConexionBD;
import cr.utn.facturacion.modelo.Producto;
import java.sql.*;
import java.util.*;
import java.math.BigDecimal;

public class ProductoDAO {
    public boolean agregar(Producto p) throws SQLException {
        String sql="INSERT INTO producto(codigo,descripcion,precio,existencia) VALUES(?,?,?,?)";
        try(Connection cn=ConexionBD.obtenerConexion(); PreparedStatement ps=cn.prepareStatement(sql)){
            ps.setString(1,p.getCodigo()); ps.setString(2,p.getDescripcion()); ps.setBigDecimal(3,p.getPrecio()); ps.setInt(4,p.getExistencia());
            return ps.executeUpdate()>0;
        }
    }
    public boolean actualizar(Producto p) throws SQLException {
        String sql="UPDATE producto SET descripcion=?,precio=?,existencia=? WHERE codigo=?";
        try(Connection cn=ConexionBD.obtenerConexion(); PreparedStatement ps=cn.prepareStatement(sql)){
            ps.setString(1,p.getDescripcion()); ps.setBigDecimal(2,p.getPrecio()); ps.setInt(3,p.getExistencia()); ps.setString(4,p.getCodigo());
            return ps.executeUpdate()>0;
        }
    }
    public boolean eliminar(String codigo) throws SQLException {
        try(Connection cn=ConexionBD.obtenerConexion(); PreparedStatement ps=cn.prepareStatement("DELETE FROM producto WHERE codigo=?")){
            ps.setString(1,codigo); return ps.executeUpdate()>0;
        }
    }
    public Producto buscar(String codigo) throws SQLException {
        try(Connection cn=ConexionBD.obtenerConexion(); PreparedStatement ps=cn.prepareStatement("SELECT * FROM producto WHERE codigo=?")){
            ps.setString(1,codigo); try(ResultSet rs=ps.executeQuery()){
                if(rs.next()) return new Producto(rs.getString("codigo"),rs.getString("descripcion"),rs.getBigDecimal("precio"),rs.getInt("existencia"));
            }
        } return null;
    }
    public List<Producto> listar() throws SQLException {
        List<Producto> lista=new ArrayList<>();
        try(Connection cn=ConexionBD.obtenerConexion(); PreparedStatement ps=cn.prepareStatement("SELECT * FROM producto"); ResultSet rs=ps.executeQuery()){
            while(rs.next()) lista.add(new Producto(rs.getString("codigo"),rs.getString("descripcion"),rs.getBigDecimal("precio"),rs.getInt("existencia")));
        } return lista;
    }
}
