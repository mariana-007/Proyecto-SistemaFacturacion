package cr.utn.facturacion.servicio;

import cr.utn.facturacion.modelo.DetalleFactura;
import java.math.BigDecimal;
import java.util.List;

public class FacturacionServicio {
    public BigDecimal calcularImporte(BigDecimal precio, int cantidad) {
        return precio.multiply(BigDecimal.valueOf(cantidad));
    }
    public BigDecimal calcularTotal(List<DetalleFactura> detalles) {
        BigDecimal total=BigDecimal.ZERO;
        for(DetalleFactura d:detalles) total=total.add(d.getImporte());
        return total;
    }
}
