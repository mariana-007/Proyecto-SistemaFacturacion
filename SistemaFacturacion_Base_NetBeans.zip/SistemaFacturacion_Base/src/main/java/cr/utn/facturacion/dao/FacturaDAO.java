package cr.utn.facturacion.dao;

import cr.utn.facturacion.conexion.ConexionBD;
import cr.utn.facturacion.modelo.*;
import java.sql.*;
import java.util.*;
import java.math.BigDecimal;
import java.time.LocalDate;

public class FacturaDAO {
    // Guarda encabezado y detalle en una sola transacción.
    public int guardar(Factura factura, List<DetalleFactura> detalles) throws SQLException {
        String sqlFactura="INSERT INTO factura(fecha,cedula_cliente,total) VALUES(?,?,?)";
        String sqlDetalle="INSERT INTO detalle_factura(numero_factura,codigo_producto,precio_unitario,cantidad,importe) VALUES(?,?,?,?,?)";
        try(Connection cn=ConexionBD.obtenerConexion()){
            cn.setAutoCommit(false);
            try {
                int numero;
                try(PreparedStatement ps=cn.prepareStatement(sqlFactura, Statement.RETURN_GENERATED_KEYS)){
                    ps.setDate(1,Date.valueOf(factura.getFecha()));
                    ps.setString(2,factura.getCedulaCliente()); ps.setBigDecimal(3,factura.getTotal());
                    ps.executeUpdate();
                    try(ResultSet rs=ps.getGeneratedKeys()){ if(!rs.next()) throw new SQLException("No se generó el número de factura."); numero=rs.getInt(1); }
                }
                try(PreparedStatement ps=cn.prepareStatement(sqlDetalle)){
                    for(DetalleFactura d:detalles){
                        ps.setInt(1,numero); ps.setString(2,d.getCodigoProducto()); ps.setBigDecimal(3,d.getPrecioUnitario());
                        ps.setInt(4,d.getCantidad()); ps.setBigDecimal(5,d.getImporte()); ps.addBatch();
                    }
                    ps.executeBatch();
                }
                cn.commit(); return numero;
            } catch(SQLException ex){ cn.rollback(); throw ex; }
            finally { cn.setAutoCommit(true); }
        }
    }
    public List<Factura> listar() throws SQLException {
        List<Factura> lista=new ArrayList<>();
        String sql="SELECT * FROM factura ORDER BY numero_factura DESC";
        try(Connection cn=ConexionBD.obtenerConexion(); PreparedStatement ps=cn.prepareStatement(sql); ResultSet rs=ps.executeQuery()){
            while(rs.next()) lista.add(new Factura(rs.getInt("numero_factura"),rs.getDate("fecha").toLocalDate(),rs.getString("cedula_cliente"),rs.getBigDecimal("total")));
        } return lista;
    }
    public List<DetalleFactura> listarDetalle(int numeroFactura) throws SQLException {
        List<DetalleFactura> lista=new ArrayList<>();
        String sql="SELECT * FROM detalle_factura WHERE numero_factura=?";
        try(Connection cn=ConexionBD.obtenerConexion(); PreparedStatement ps=cn.prepareStatement(sql)){
            ps.setInt(1,numeroFactura); try(ResultSet rs=ps.executeQuery()){
                while(rs.next()){
                    DetalleFactura d=new DetalleFactura(rs.getString("codigo_producto"),rs.getBigDecimal("precio_unitario"),rs.getInt("cantidad"),rs.getBigDecimal("importe"));
                    d.setIdDetalle(rs.getInt("id_detalle")); d.setNumeroFactura(rs.getInt("numero_factura")); lista.add(d);
                }
            }
        } return lista;
    }
}
