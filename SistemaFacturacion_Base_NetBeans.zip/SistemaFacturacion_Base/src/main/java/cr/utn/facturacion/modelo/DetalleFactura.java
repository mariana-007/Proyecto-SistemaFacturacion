package cr.utn.facturacion.modelo;

import java.math.BigDecimal;

public class DetalleFactura {
    private int idDetalle, numeroFactura, cantidad;
    private String codigoProducto;
    private BigDecimal precioUnitario, importe;
    public DetalleFactura() {}
    public DetalleFactura(String codigoProducto, BigDecimal precioUnitario, int cantidad, BigDecimal importe) {
        this.codigoProducto=codigoProducto; this.precioUnitario=precioUnitario;
        this.cantidad=cantidad; this.importe=importe;
    }
    public int getIdDetalle(){return idDetalle;} public void setIdDetalle(int v){idDetalle=v;}
    public int getNumeroFactura(){return numeroFactura;} public void setNumeroFactura(int v){numeroFactura=v;}
    public String getCodigoProducto(){return codigoProducto;} public void setCodigoProducto(String v){codigoProducto=v;}
    public BigDecimal getPrecioUnitario(){return precioUnitario;} public void setPrecioUnitario(BigDecimal v){precioUnitario=v;}
    public int getCantidad(){return cantidad;} public void setCantidad(int v){cantidad=v;}
    public BigDecimal getImporte(){return importe;} public void setImporte(BigDecimal v){importe=v;}
}
