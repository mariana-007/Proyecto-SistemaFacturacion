package cr.utn.facturacion.dao;

import cr.utn.facturacion.conexion.ConexionBD;
import cr.utn.facturacion.modelo.Usuario;
import java.sql.*;
import java.util.*;

public class UsuarioDAO {
    public boolean validarLogin(String cedula, String contrasena) throws SQLException {
        String sql="SELECT cedula FROM usuario WHERE cedula=? AND contrasena=?";
        try(Connection cn=ConexionBD.obtenerConexion(); PreparedStatement ps=cn.prepareStatement(sql)){
            ps.setString(1,cedula); ps.setString(2,contrasena);
            try(ResultSet rs=ps.executeQuery()){ return rs.next(); }
        }
    }
    public boolean agregar(Usuario u) throws SQLException {
        String sql="INSERT INTO usuario(cedula,nombre,contrasena) VALUES(?,?,?)";
        try(Connection cn=ConexionBD.obtenerConexion(); PreparedStatement ps=cn.prepareStatement(sql)){
            ps.setString(1,u.getCedula()); ps.setString(2,u.getNombre()); ps.setString(3,u.getContrasena()); return ps.executeUpdate()>0;
        }
    }
    public boolean actualizar(Usuario u) throws SQLException {
        String sql="UPDATE usuario SET nombre=?,contrasena=? WHERE cedula=?";
        try(Connection cn=ConexionBD.obtenerConexion(); PreparedStatement ps=cn.prepareStatement(sql)){
            ps.setString(1,u.getNombre()); ps.setString(2,u.getContrasena()); ps.setString(3,u.getCedula()); return ps.executeUpdate()>0;
        }
    }
    public boolean eliminar(String cedula) throws SQLException {
        try(Connection cn=ConexionBD.obtenerConexion(); PreparedStatement ps=cn.prepareStatement("DELETE FROM usuario WHERE cedula=?")){
            ps.setString(1,cedula); return ps.executeUpdate()>0;
        }
    }
    public List<Usuario> listar() throws SQLException {
        List<Usuario> lista=new ArrayList<>();
        try(Connection cn=ConexionBD.obtenerConexion(); PreparedStatement ps=cn.prepareStatement("SELECT * FROM usuario"); ResultSet rs=ps.executeQuery()){
            while(rs.next()) lista.add(new Usuario(rs.getString("cedula"),rs.getString("nombre"),rs.getString("contrasena")));
        } return lista;
    }
}
