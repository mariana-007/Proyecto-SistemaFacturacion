package cr.utn.facturacion.modelo;

public class Usuario {
    private String cedula, nombre, contrasena;
    public Usuario() {}
    public Usuario(String cedula, String nombre, String contrasena) {
        this.cedula=cedula; this.nombre=nombre; this.contrasena=contrasena;
    }
    public String getCedula(){return cedula;} public void setCedula(String v){cedula=v;}
    public String getNombre(){return nombre;} public void setNombre(String v){nombre=v;}
    public String getContrasena(){return contrasena;} public void setContrasena(String v){contrasena=v;}
}
