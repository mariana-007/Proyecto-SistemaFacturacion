package cr.utn.facturacion.modelo;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Factura {
    private int numeroFactura;
    private LocalDate fecha;
    private String cedulaCliente;
    private BigDecimal total;
    public Factura() {}
    public Factura(int numeroFactura, LocalDate fecha, String cedulaCliente, BigDecimal total) {
        this.numeroFactura=numeroFactura; this.fecha=fecha; this.cedulaCliente=cedulaCliente; this.total=total;
    }
    public int getNumeroFactura(){return numeroFactura;} public void setNumeroFactura(int v){numeroFactura=v;}
    public LocalDate getFecha(){return fecha;} public void setFecha(LocalDate v){fecha=v;}
    public String getCedulaCliente(){return cedulaCliente;} public void setCedulaCliente(String v){cedulaCliente=v;}
    public BigDecimal getTotal(){return total;} public void setTotal(BigDecimal v){total=v;}
}
