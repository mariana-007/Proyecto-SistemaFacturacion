package cr.utn.facturacion.modelo;

public class Cliente {
    private String cedula, nombre, telefono, correo;
    public Cliente() {}
    public Cliente(String cedula, String nombre, String telefono, String correo) {
        this.cedula=cedula; this.nombre=nombre; this.telefono=telefono; this.correo=correo;
    }
    public String getCedula(){return cedula;} public void setCedula(String v){cedula=v;}
    public String getNombre(){return nombre;} public void setNombre(String v){nombre=v;}
    public String getTelefono(){return telefono;} public void setTelefono(String v){telefono=v;}
    public String getCorreo(){return correo;} public void setCorreo(String v){correo=v;}
}
