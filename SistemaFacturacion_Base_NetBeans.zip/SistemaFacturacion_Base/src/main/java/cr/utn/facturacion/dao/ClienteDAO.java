package cr.utn.facturacion.dao;

import cr.utn.facturacion.conexion.ConexionBD;
import cr.utn.facturacion.modelo.Cliente;
import java.sql.*;
import java.util.*;

public class ClienteDAO {
    public boolean agregar(Cliente c) throws SQLException {
        String sql="INSERT INTO cliente(cedula,nombre,telefono,correo) VALUES(?,?,?,?)";
        try(Connection cn=ConexionBD.obtenerConexion(); PreparedStatement ps=cn.prepareStatement(sql)){
            ps.setString(1,c.getCedula()); ps.setString(2,c.getNombre()); ps.setString(3,c.getTelefono()); ps.setString(4,c.getCorreo());
            return ps.executeUpdate()>0;
        }
    }
    public boolean actualizar(Cliente c) throws SQLException {
        String sql="UPDATE cliente SET nombre=?,telefono=?,correo=? WHERE cedula=?";
        try(Connection cn=ConexionBD.obtenerConexion(); PreparedStatement ps=cn.prepareStatement(sql)){
            ps.setString(1,c.getNombre()); ps.setString(2,c.getTelefono()); ps.setString(3,c.getCorreo()); ps.setString(4,c.getCedula());
            return ps.executeUpdate()>0;
        }
    }
    public boolean eliminar(String cedula) throws SQLException {
        try(Connection cn=ConexionBD.obtenerConexion(); PreparedStatement ps=cn.prepareStatement("DELETE FROM cliente WHERE cedula=?")){
            ps.setString(1,cedula); return ps.executeUpdate()>0;
        }
    }
    public Cliente buscar(String cedula) throws SQLException {
        try(Connection cn=ConexionBD.obtenerConexion(); PreparedStatement ps=cn.prepareStatement("SELECT * FROM cliente WHERE cedula=?")){
            ps.setString(1,cedula); try(ResultSet rs=ps.executeQuery()){
                if(rs.next()) return new Cliente(rs.getString("cedula"),rs.getString("nombre"),rs.getString("telefono"),rs.getString("correo"));
            }
        } return null;
    }
    public List<Cliente> listar() throws SQLException {
        List<Cliente> lista=new ArrayList<>();
        try(Connection cn=ConexionBD.obtenerConexion(); PreparedStatement ps=cn.prepareStatement("SELECT * FROM cliente"); ResultSet rs=ps.executeQuery()){
            while(rs.next()) lista.add(new Cliente(rs.getString("cedula"),rs.getString("nombre"),rs.getString("telefono"),rs.getString("correo")));
        } return lista;
    }
}
